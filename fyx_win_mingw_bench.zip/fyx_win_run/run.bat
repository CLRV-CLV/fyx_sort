@echo off
chcp 65001 >nul
if not exist fyx_bench.exe (
  echo 请先运行 build.bat
  exit /b 1
)

echo ===== 4 线程 =====
fyx_bench.exe 4 > result_4t.txt
type result_4t.txt
echo.
echo ===== 8 线程 =====
fyx_bench.exe 8 > result_8t.txt
type result_8t.txt
echo.
echo ===== 16 线程 =====
fyx_bench.exe 16 > result_16t.txt
type result_16t.txt

echo.
echo 已写入 result_4t.txt  result_8t.txt  result_16t.txt
echo i7-14700K 是 8 性能核 + 12 能效核。4/8 线程大致落在性能核；16 会用到能效核，并行加速可能变差，这是正常现象。
