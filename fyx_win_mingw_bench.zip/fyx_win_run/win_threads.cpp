// MinGW-w64 线程档测试：fyx 串行 / fyx 并行 / 标准库 / 模式击败快排
// 用法: fyx_bench.exe <线程数>     例如 fyx_bench.exe 8
// 线程数同时写入环境变量 FYX_THREADS（进程内须在第一次排序前生效，
// 本程序在 main 开头 setenv/putenv，然后才调用 fyx）。
//
// i7-14700K 没有 AVX-512：向量快排（谷歌/英特尔）在这颗 CPU 上不是沙箱
// 那套 AVX-512 路径；本包不捆绑它们（MinGW 编 highway 很痛）。
#define FYX_ENABLE_TEST_HOOKS 0
#include "fyx_sort.hpp"
#include "pdqsort.h"

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <random>
#include <string>
#include <vector>

#ifdef _WIN32
#  include <stdlib.h>
#endif

using clk = std::chrono::steady_clock;
static double med(std::vector<double> v) {
    std::sort(v.begin(), v.end());
    return v[v.size() / 2];
}

enum Dist { Random, Sorted, Reverse, Nearly, Low16, Mod8, Blockswap };

static const char* dist_name(Dist d) {
    switch (d) {
        case Random:    return "乱序";
        case Sorted:    return "已排序";
        case Reverse:   return "逆序";
        case Nearly:    return "近有序";
        case Low16:     return "十六取值";
        case Mod8:      return "八取值";
        case Blockswap: return "块交换";
        default:        return "?";
    }
}

template <class T>
static void fill(std::vector<T>& v, Dist d, std::mt19937_64& rng) {
    const std::size_t n = v.size();
    if (d == Random) {
        for (auto& x : v) x = static_cast<T>(rng());
        return;
    }
    if (d == Low16) {
        for (auto& x : v) x = static_cast<T>(rng() % 16);
        return;
    }
    if (d == Mod8) {
        for (std::size_t i = 0; i < n; ++i) v[i] = static_cast<T>(i % 8);
        return;
    }
    for (std::size_t i = 0; i < n; ++i) v[i] = static_cast<T>(i);
    if (d == Reverse) std::reverse(v.begin(), v.end());
    if (d == Nearly) {
        std::size_t swaps = n / 1000 + 1;
        for (std::size_t k = 0; k < swaps && n > 66; ++k) {
            std::size_t i = rng() % (n - 66);
            std::size_t j = i + 1 + rng() % 64;
            std::swap(v[i], v[j]);
        }
    }
    if (d == Blockswap) {
        const std::size_t bs = 128;
        const std::size_t nb = n / bs;
        for (std::size_t k = 0; k < 20 && nb > 4; ++k) {
            std::size_t i = rng() % (nb - 1);
            std::size_t j = i + 1 + rng() % 4;
            if (j >= nb) j = nb - 1;
            for (std::size_t t = 0; t < bs; ++t) std::swap(v[i * bs + t], v[j * bs + t]);
        }
    }
}

template <class T>
static void row(const char* type, Dist d, std::size_t n, int threads) {
    std::mt19937_64 rng(0xC0FFEEULL + n + (unsigned)d);
    std::vector<T> src(n), a(n);
    fill(src, d, rng);

    fyx::Options off;
    off.parallel = fyx::Tri::Off;
    off.threads = 1;
    fyx::Options on;
    on.parallel = fyx::Tri::On;
    on.threads = threads;

    a = src; fyx::sort(a.data(), n, off);
    a = src; fyx::sort(a.data(), n, on);
    a = src; std::sort(a.begin(), a.end());
    a = src; pdqsort(a.begin(), a.end());

    std::vector<double> ts, tp, tstd, tpdq;
    for (int r = 0; r < 5; ++r) {
        a = src;
        auto t0 = clk::now();
        fyx::sort(a.data(), n, off);
        ts.push_back(std::chrono::duration<double>(clk::now() - t0).count());

        a = src;
        auto t1 = clk::now();
        fyx::sort(a.data(), n, on);
        tp.push_back(std::chrono::duration<double>(clk::now() - t1).count());

        a = src;
        auto t2 = clk::now();
        std::sort(a.begin(), a.end());
        tstd.push_back(std::chrono::duration<double>(clk::now() - t2).count());

        a = src;
        auto t3 = clk::now();
        pdqsort(a.begin(), a.end());
        tpdq.push_back(std::chrono::duration<double>(clk::now() - t3).count());
    }
    const double fs = med(ts) * 1e3, fp = med(tp) * 1e3, st = med(tstd) * 1e3, pd = med(tpdq) * 1e3;
    std::printf("  %-6s %-8s  fyx串行=%8.3f  fyx并行=%8.3f  标准库=%8.3f  模式击败=%8.3f  并/串=%.2f  串/标=%.2f  并/标=%.2f\n",
                type, dist_name(d), fs, fp, st, pd, fs > 0 ? fp / fs : 0, st > 0 ? fs / st : 0, st > 0 ? fp / st : 0);
}

static void set_thread_env(int n) {
    char num[16];
    std::snprintf(num, sizeof(num), "%d", n);
#ifdef _WIN32
    static char buf[64];
    std::snprintf(buf, sizeof(buf), "FYX_THREADS=%s", num);
    _putenv(buf);
#else
    setenv("FYX_THREADS", num, 1);
#endif
}

int main(int argc, char** argv) {
    int threads = 8;
    if (argc >= 2) threads = std::atoi(argv[1]);
    if (threads < 1) threads = 1;
    if (threads > 256) threads = 256;
    set_thread_env(threads);

    unsigned hc = std::thread::hardware_concurrency();
    std::printf("机器逻辑线程=%u  本次 fyx 线程池=%d  （14700K 无 AVX-512，走 AVX2）\n", hc, threads);
    std::printf("比值：并/串 <1 表示并行更快；串/标 <1 表示 fyx 串行快于标准库\n");

    const std::size_t n = 1000000;
    Dist ds[] = {Random, Sorted, Reverse, Nearly, Low16, Mod8, Blockswap};
    std::printf("\n==== int32  n=%zu ====\n", n);
    for (Dist d : ds) row<std::int32_t>("int32", d, n, threads);
    std::printf("\n==== int64  n=%zu ====\n", n);
    for (Dist d : ds) row<std::int64_t>("int64", d, n, threads);
    std::printf("\n==== double n=%zu ====\n", n);
    for (Dist d : ds) row<double>("double", d, n, threads);
    return 0;
}
