@echo off
chcp 65001 >nul
echo 用 MinGW-w64 的 g++ 编译。请先把 g++.exe 加到 PATH。
echo 若提示找不到 pthread，在最后加上  -lpthread
echo.

where g++ >nul 2>&1
if errorlevel 1 (
  echo 找不到 g++。请安装 MinGW-w64 并加入 PATH。
  exit /b 1
)

REM 14700K 无 AVX-512。必须关掉，否则 MinGW 在 -march=native(AVX2) 下会把
REM AVX-512 内联进默认函数而编不过，或编过却在运行时非法指令。
g++ -std=c++17 -O3 -march=native -DNDEBUG -DFYX_DISABLE_AVX512 -pthread -I. -Ivendor win_threads.cpp -o fyx_bench.exe -lpthread
if errorlevel 1 (
  echo 第一次失败，改试无 -pthread、只链 winpthread：
  g++ -std=c++17 -O3 -march=native -DNDEBUG -DFYX_DISABLE_AVX512 -I. -Ivendor win_threads.cpp -o fyx_bench.exe -lwinpthread
)
if errorlevel 1 (
  echo 编译失败。MinGW 限制：需要 winpthread；不要用 MSYS 的 g++ 和 mingw 混链。
  exit /b 1
)
echo 编译成功: fyx_bench.exe
g++ -v 2>&1 | findstr /i "version Target"
echo.
echo 下一步请运行 run.bat
