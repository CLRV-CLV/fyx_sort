#!/usr/bin/env bash
# Linux 全算法编译。缺什么就跳过什么，保证最后一定产出 fyx_bench。
set -u
cd "$(dirname "$0")"
ROOT="$PWD"
VENDOR="$ROOT/vendor"
mkdir -p "$VENDOR"

need() { command -v "$1" >/dev/null 2>&1 || { echo "需要 $1"; exit 1; }; }
need g++
need cmake
need git

# Kali 4核8G：并行编译过多会把内存打满。默认 2 路。
JOBS="${FYX_BUILD_JOBS:-2}"

clone() {
  local url="$1" dir="$2" branch="${3:-}"
  if [ -d "$dir/.git" ] || [ -f "$dir/CMakeLists.txt" ] || [ -f "$dir/include/ips4o.hpp" ] || [ -f "$dir/pdqsort.h" ]; then
    return 0
  fi
  if [ -n "$branch" ]; then git clone --depth 1 --branch "$branch" "$url" "$dir"
  else git clone --depth 1 "$url" "$dir"; fi
}

echo "== 依赖 =="
clone https://github.com/orlp/pdqsort.git "$VENDOR/pdqsort"
clone https://github.com/ips4o/ips4o.git "$VENDOR/ips4o"
clone https://github.com/google/highway.git "$VENDOR/highway" 1.4.0
clone https://github.com/intel/x86-simd-sort.git "$VENDOR/x86-simd-sort"

HAVE_VQSORT=0
HAVE_XSS=0
HAVE_IPS4O=0
HAVE_IPS4O_PAR=0
HWY_LINK=""
TBB_INC=""
TBB_LINK=""
XSS_INC=""
DEFS=""

if [ -f "$VENDOR/pdqsort/pdqsort.h" ]; then
  DEFS="$DEFS -I$VENDOR/pdqsort"
fi
# 现行 ips4o 头文件无条件 #include <tbb/concurrent_queue.h>，没有 TBB 时整库都不能编。

# 谷歌向量：编 highway contrib
if [ -f "$VENDOR/highway/CMakeLists.txt" ]; then
  if [ ! -f "$VENDOR/highway/build/libhwy_contrib.a" ]; then
    echo "== 编译 highway (谷歌向量) =="
    cmake -S "$VENDOR/highway" -B "$VENDOR/highway/build" \
      -DCMAKE_BUILD_TYPE=Release -DHWY_ENABLE_TESTS=OFF \
      -DHWY_ENABLE_EXAMPLES=OFF -DBUILD_TESTING=OFF -DHWY_ENABLE_CONTRIB=ON \
      || true
    cmake --build "$VENDOR/highway/build" -j"$JOBS" || true
  fi
  if [ -f "$VENDOR/highway/build/libhwy_contrib.a" ]; then
    HAVE_VQSORT=1
    DEFS="$DEFS -DHAVE_VQSORT -I$VENDOR/highway"
    HWY_LINK="-L$VENDOR/highway/build -lhwy_contrib -lhwy"
  else
    echo "highway 未编过，跳过谷歌向量"
  fi
fi

# 英特尔向量：无 AVX-512 的机器仍可走其 AVX2 头文件；编不过就关掉
if [ -f "$VENDOR/x86-simd-sort/src/x86simdsort-static-incl.h" ]; then
  HAVE_XSS=1
  XSS_INC="-I$VENDOR/x86-simd-sort/src"
  DEFS="$DEFS -DHAVE_XSS $XSS_INC"
fi

# 样本排序：先系统 TBB，否则自编 oneTBB
if pkg-config --exists tbb 2>/dev/null; then
  TBB_INC="$(pkg-config --cflags tbb)"
  TBB_LINK="$(pkg-config --libs tbb)"
elif [ -f /usr/include/tbb/tbb.h ] || [ -f /usr/include/oneapi/tbb.h ]; then
  TBB_LINK="-ltbb"
else
  echo "无系统 TBB。Kali 请: sudo apt install libtbb-dev"
  echo "8G 内存机不现场编 oneTBB（容易 OOM）。样本排序将跳过。"
fi
if [ -n "$TBB_LINK" ] && [ -f "$VENDOR/ips4o/include/ips4o.hpp" ]; then
  HAVE_IPS4O=1
  HAVE_IPS4O_PAR=1
  DEFS="$DEFS -DHAVE_IPS4O -DHAVE_IPS4O_PAR -I$VENDOR/ips4o/include $TBB_INC"
  echo "样本排序串行+并行 开启"
else
  echo "无 TBB，跳过样本排序（避免编不过）"
  HAVE_IPS4O=0
  HAVE_IPS4O_PAR=0
  TBB_LINK=""
fi

AVX_FLAG="-march=native"
# 无 AVX-512 时关掉 fyx 的 512 内核，避免 GCC 把内联编进 AVX2 函数
if ! grep -q avx512f /proc/cpuinfo 2>/dev/null; then
  AVX_FLAG="$AVX_FLAG -DFYX_DISABLE_AVX512"
  echo "本机无 AVX-512，fyx 走 AVX2"
fi

COMMON="-std=c++17 -O3 $AVX_FLAG -DNDEBUG -pthread -I. $DEFS"

try_link() {
  # $1 = extra defs, $2 = extra libs
  g++ $COMMON $1 linux_threads.cpp -o fyx_bench $HWY_LINK $2 -lpthread -ldl
}

echo "== 链测试程序 =="
EXTRA_LIBS="$TBB_LINK"
if [ "$HAVE_IPS4O_PAR" = 1 ]; then
  if try_link "" "$EXTRA_LIBS"; then
    echo "成功：含样本排序并行"
  else
    echo "带 TBB 失败，关掉样本排序并行"
    HAVE_IPS4O_PAR=0
    COMMON="${COMMON//-DHAVE_IPS4O_PAR/}"
    EXTRA_LIBS=""
    if try_link "" ""; then
      echo "成功：无样本排序并行"
    else
      echo "再关英特尔向量"
      COMMON="${COMMON//-DHAVE_XSS/}"
      COMMON="${COMMON//-I$VENDOR\/x86-simd-sort\/src/}"
      try_link "" "" || {
        echo "再关谷歌向量"
        COMMON="${COMMON//-DHAVE_VQSORT/}"
        HWY_LINK=""
        try_link "" "" || { echo "连最小集都失败"; exit 1; }
      }
    fi
  fi
else
  if try_link "" ""; then
    echo "成功"
  else
    echo "关英特尔向量重试"
    COMMON="${COMMON//-DHAVE_XSS/}"
    if try_link "" ""; then
      echo "成功（无英特尔向量）"
    else
      echo "关谷歌向量重试"
      COMMON="${COMMON//-DHAVE_VQSORT/}"
      HWY_LINK=""
      try_link "" "" || { echo "失败"; exit 1; }
    fi
  fi
fi

echo
echo "产出: $ROOT/fyx_bench"
echo "下一步: ./run.sh"
