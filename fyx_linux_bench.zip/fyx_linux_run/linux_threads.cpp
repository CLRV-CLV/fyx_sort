// Linux 全算法线程档：fyx 串行 / fyx 并行 / 标准库 / 模式击败 / 谷歌向量 /
// 英特尔向量 / 样本排序(串) / 样本排序(并)
// 用法: fyx_bench <线程数>
#define FYX_ENABLE_TEST_HOOKS 0
#include "fyx_sort.hpp"
#include "pdqsort.h"

#ifdef HAVE_VQSORT
#  include "hwy/contrib/sort/vqsort.h"
#endif
#ifdef HAVE_XSS
#  include "x86simdsort-static-incl.h"
#endif
#ifdef HAVE_IPS4O
#  include "ips4o.hpp"
#endif

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <random>
#include <string>
#include <type_traits>
#include <vector>
#include <thread>

using clk = std::chrono::steady_clock;
static double med(std::vector<double> v) {
    std::sort(v.begin(), v.end());
    return v[v.size() / 2];
}

enum Dist { Random, Sorted, Reverse, Nearly, Low16, Mod8, Blockswap };
static const char* dist_name(Dist d) {
    switch (d) {
        case Random:    return "乱序";
        case Sorted:    return "已排序";
        case Reverse:   return "逆序";
        case Nearly:    return "近有序";
        case Low16:     return "十六取值";
        case Mod8:      return "八取值";
        case Blockswap: return "块交换";
        default:        return "?";
    }
}

template <class T>
static void fill(std::vector<T>& v, Dist d, std::mt19937_64& rng) {
    const std::size_t n = v.size();
    if (d == Random) {
        for (auto& x : v) {
            if constexpr (std::is_floating_point<T>::value) {
                x = static_cast<T>((static_cast<int64_t>(rng() >> 11) % 2000000) - 1000000) / T(7);
            } else {
                x = static_cast<T>(rng());
            }
        }
        return;
    }
    if (d == Low16) { for (auto& x : v) x = static_cast<T>(rng() % 16); return; }
    if (d == Mod8) { for (std::size_t i = 0; i < n; ++i) v[i] = static_cast<T>(i % 8); return; }
    for (std::size_t i = 0; i < n; ++i) v[i] = static_cast<T>(i);
    if (d == Reverse) std::reverse(v.begin(), v.end());
    if (d == Nearly && n > 66) {
        for (std::size_t k = 0; k < n / 1000 + 1; ++k) {
            std::size_t i = rng() % (n - 66);
            std::swap(v[i], v[i + 1 + rng() % 64]);
        }
    }
    if (d == Blockswap) {
        const std::size_t bs = 128, nb = n / bs;
        for (std::size_t k = 0; k < 20 && nb > 4; ++k) {
            std::size_t i = rng() % (nb - 1);
            std::size_t j = i + 1 + (rng() % 4);
            if (j >= nb) j = nb - 1;
            for (std::size_t t = 0; t < bs; ++t) std::swap(v[i * bs + t], v[j * bs + t]);
        }
    }
}

static void print_ms(const char* name, double ms, bool ok) {
    if (!ok) std::printf("  %s=未编入", name);
    else std::printf("  %s=%8.3f", name, ms);
}

template <class T>
static void row(const char* type, Dist d, std::size_t n, int threads) {
    std::mt19937_64 rng(0xC0FFEEULL + n + (unsigned)d);
    std::vector<T> src(n), a(n);
    fill(src, d, rng);

    fyx::Options off; off.parallel = fyx::Tri::Off; off.threads = 1;
    fyx::Options on;  on.parallel  = fyx::Tri::On;  on.threads = threads;

    auto run = [&](auto&& fn) {
        a = src;
        auto t0 = clk::now();
        fn();
        return std::chrono::duration<double>(clk::now() - t0).count();
    };

    // 预热，避免把冷缓存算进中位
    a = src; fyx::sort(a.data(), n, off);
    a = src; fyx::sort(a.data(), n, on);
    a = src; std::sort(a.begin(), a.end());
    a = src; pdqsort(a.begin(), a.end());
#ifdef HAVE_VQSORT
    a = src; hwy::VQSort(a.data(), n, hwy::SortAscending());
#endif
#ifdef HAVE_XSS
    if constexpr (std::is_same<T, std::int32_t>::value || std::is_same<T, std::int64_t>::value ||
                  std::is_same<T, double>::value) {
        a = src; x86simdsortStatic::qsort(a.data(), n);
    }
#endif
#ifdef HAVE_IPS4O
    a = src; ips4o::sort(a.begin(), a.end());
#ifdef HAVE_IPS4O_PAR
    a = src; ips4o::parallel::sort(a.begin(), a.end());
#endif
#endif

    std::vector<double> ts, tp, tstd, tpdq, tvq, txss, tips, tipsp;
    for (int r = 0; r < 5; ++r) {
        ts.push_back(run([&] { fyx::sort(a.data(), n, off); }));
        tp.push_back(run([&] { fyx::sort(a.data(), n, on); }));
        tstd.push_back(run([&] { std::sort(a.begin(), a.end()); }));
        tpdq.push_back(run([&] { pdqsort(a.begin(), a.end()); }));
#ifdef HAVE_VQSORT
        tvq.push_back(run([&] { hwy::VQSort(a.data(), n, hwy::SortAscending()); }));
#endif
#ifdef HAVE_XSS
        if constexpr (std::is_same<T, std::int32_t>::value || std::is_same<T, std::int64_t>::value ||
                      std::is_same<T, double>::value) {
            txss.push_back(run([&] { x86simdsortStatic::qsort(a.data(), n); }));
        }
#endif
#ifdef HAVE_IPS4O
        tips.push_back(run([&] { ips4o::sort(a.begin(), a.end()); }));
#ifdef HAVE_IPS4O_PAR
        tipsp.push_back(run([&] { ips4o::parallel::sort(a.begin(), a.end()); }));
#endif
#endif
    }

    std::printf("  %-6s %-8s", type, dist_name(d));
    print_ms("fyx串行", med(ts) * 1e3, true);
    print_ms("fyx并行", med(tp) * 1e3, true);
    print_ms("标准库", med(tstd) * 1e3, true);
    print_ms("模式击败", med(tpdq) * 1e3, true);
    print_ms("谷歌向量", tvq.empty() ? 0 : med(tvq) * 1e3, !tvq.empty());
    print_ms("英特尔向量", txss.empty() ? 0 : med(txss) * 1e3, !txss.empty());
    print_ms("样本排序", tips.empty() ? 0 : med(tips) * 1e3, !tips.empty());
    print_ms("样本排序并", tipsp.empty() ? 0 : med(tipsp) * 1e3, !tipsp.empty());
    std::printf("\n");
}

int main(int argc, char** argv) {
    int threads = 8;
    if (argc >= 2) threads = std::atoi(argv[1]);
    if (threads < 1) threads = 1;
    char num[16];
    std::snprintf(num, sizeof(num), "%d", threads);
    setenv("FYX_THREADS", num, 1);
    setenv("TBB_NUM_THREADS", num, 1);

    unsigned hc = std::thread::hardware_concurrency();
    std::printf("逻辑线程=%u  本次线程档=%d\n", hc, threads);
    std::printf("已编入:");
    std::printf(" fyx串行 fyx并行 标准库 模式击败");
#ifdef HAVE_VQSORT
    std::printf(" 谷歌向量");
#else
    std::printf(" [无谷歌向量]");
#endif
#ifdef HAVE_XSS
    std::printf(" 英特尔向量");
#else
    std::printf(" [无英特尔向量]");
#endif
#ifdef HAVE_IPS4O
    std::printf(" 样本排序");
#else
    std::printf(" [无样本排序]");
#endif
#ifdef HAVE_IPS4O_PAR
    std::printf(" 样本排序并");
#else
    std::printf(" [无样本排序并]");
#endif
    std::printf("\n单位毫秒，中位 5 次。n=1000000\n");

    const std::size_t n = 1000000;
    Dist ds[] = {Random, Sorted, Reverse, Nearly, Low16, Mod8, Blockswap};
    std::printf("\n==== int32 ====\n");
    for (Dist d : ds) row<std::int32_t>("int32", d, n, threads);
    std::printf("\n==== int64 ====\n");
    for (Dist d : ds) row<std::int64_t>("int64", d, n, threads);
    std::printf("\n==== double ====\n");
    for (Dist d : ds) row<double>("double", d, n, threads);
    return 0;
}
