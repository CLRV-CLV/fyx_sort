#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
if [ ! -x ./fyx_bench ]; then
  echo "请先 ./build.sh"
  exit 1
fi
echo "===== 4 线程 ====="
./fyx_bench 4 | tee result_4t.txt
echo
echo "===== 8 线程 ====="
./fyx_bench 8 | tee result_8t.txt
echo
echo "===== 16 线程 ====="
./fyx_bench 16 | tee result_16t.txt
echo
echo "已写入 result_4t.txt result_8t.txt result_16t.txt"
